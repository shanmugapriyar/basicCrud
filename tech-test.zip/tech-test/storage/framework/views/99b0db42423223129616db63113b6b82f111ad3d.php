<?php $__env->startSection('title', $people->name); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    // you can add something here
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>	
	<h1><?php echo e($people->name); ?></h1>
	
	Height: <?php echo e($people->height); ?> | Skin Color: <?php echo e($people->skin_color); ?> | Hair Color: <?php echo e($people->hair_color); ?>

	
	<p><?php echo e($people->films); ?></p>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tech-test\resources\views/people/show.blade.php ENDPATH**/ ?>