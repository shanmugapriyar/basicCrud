<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    // you can add something here
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<h1><?php echo e($title); ?></h1>

	<?php echo Form::open([
		'route' => 'people.store'
	]); ?>


	<table>
		<tr>
			<td><?php echo Form::label('name', 'Title', ['class' => 'control-label']); ?></td>
			<td><?php echo Form::text('name', null, ['class' => 'form-control', 'size' => 64, ]); ?></td>
		</tr>
		<tr>
			<td><?php echo Form::label('height', 'Height', ['class' => 'control-label']); ?></td>
			<td><?php echo Form::text('height', null, ['class' => 'form-control', 'size' => 64, ]); ?></td>
		</tr>
		<tr>
			<td><?php echo Form::label('hair_color', 'Hair Color', ['class' => 'control-label']); ?></td>
			<td><?php echo Form::text('hair_color', null, ['class' => 'form-control', 'size' => 64, ]); ?></td>
		</tr>
		<tr>
			<td><?php echo Form::label('skin_color', 'Skin Color', ['class' => 'control-label']); ?></td>
			<td><?php echo Form::text('skin_color', null, ['class' => 'form-control', 'size' => 64, ]); ?></td>
		</tr>
		<tr>
			<td valign="top"><?php echo Form::label('films', 'Films', ['class' => 'control-label']); ?></td>
			<td><?php echo Form::textarea('films', null, ['class' => 'form-control']); ?></td>
		</tr>	
		<tr>
			<td></td>
			<td><?php echo Form::submit('Submit', ['class' => 'btn btn-submit']); ?></td>
		</tr>
	</table>		
	
	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tech-test\resources\views/people/create.blade.php ENDPATH**/ ?>