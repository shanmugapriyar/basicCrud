<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
        <?php $__env->startSection('header'); ?>
            <a href="<?php echo e(route('people.index')); ?>">Home</a> | <a href="<?php echo e(route('people.create')); ?>">Add People</a>
        <?php echo $__env->yieldSection(); ?>
        
        <?php if(Session::has('flash_message')): ?>
			<div style="color:green; border:1px solid #aaa; padding:4px; margin-top:10px">
				<?php echo e(Session::get('flash_message')); ?>

			</div>
		<?php endif; ?>

		<?php if($errors->any()): ?>
			<div style="color:red; border:1px solid #aaa; padding:4px; margin-top:10px">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<p><?php echo e($error); ?></p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>
		
        <div>			
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        
       
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\tech-test\resources\views/layouts/master.blade.php ENDPATH**/ ?>