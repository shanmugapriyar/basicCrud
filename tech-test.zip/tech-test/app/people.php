<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class people extends Model
{
    protected $table = 'people';
    public $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = array('name', 'height', 'films', 'hair_color', 'skin_color', 'created_at', 'updated_at');
    protected $guarded = array();

}
