<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use Session;
use App\People;

class PeopleController extends Controller
{
    /** 
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function getAllPeople() {
        $people = People::get()->toJson(JSON_PRETTY_PRINT);
        return response($people, 200);
      }
    public function getPeople($id) {
        if (People::where('id', $id)->exists()) {
          $people = People::where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
          return response($people, 200);
        } else {
          return response()->json([
            "message" => "People not found"
          ], 404);
        }
      }
      public function createPeople(Request $request) {
        $people = new People;
        $people->name = $request->name;
        $people->height = $request->height;
        $people->skin_color = $request->skin_color;
        $people->hair_color = $request->hair_color;
        $people->films = $request->films;

        $people->save();
  
        return response()->json([
          "message" => "People record created"
        ], 201);
      }
      public function updatePeople(Request $request, $id) {
        if (People::where('id', $id)->exists()) {
          $people = People::find($id);
          $people->name = is_null($request->name) ? $people->name : $request->name;
          $people->height = is_null($request->height) ? $people->height : $request->height;
          $people->skin_color = is_null($request->skin_color) ? $people->skin_color : $request->skin_color;
          $people->hair_color = is_null($request->hair_color) ? $people->hair_color : $request->hair_color;
          $people->films = is_null($request->films) ? $people->films : $request->films;
          
          $people->save();
  
          return response()->json([
            "message" => "records updated successfully"
          ], 200);
        } else {
          return response()->json([
            "message" => "people not found"
          ], 404);
        }
      }
      public function deletePeople ($id) {
        if(People::where('id', $id)->exists()) {
          $people = People::find($id);
          $people->delete();
  
          return response()->json([
            "message" => "records deleted"
          ], 202);
        } else {
          return response()->json([
            "message" => "people not found"
          ], 404);
        }
      }
      public function getPeopleFromExternal(){
        $data=$this->curlApi();
        try{
          $result=$data->results;
          $insert='';
          foreach($result as $key=>$value){
            $people = People::where('name', $value->name)->first();
            if(empty($people)){
              $response['name']=$value->name;
              $response['height']=$value->height;
              $response['skin_color']=$value->skin_color;
              $response['hair_color']=$value->hair_color;
              $response['films']=json_encode($value->films,true);
              if(People::insert($response)){
                $insert=1;
              }
            }
            
          }
          if($insert==1){
            echo "inserted Successfully";
          }else{
            echo "Nothing to insert";

          }
        }
        catch (Exception $e) {
          $errorMessage = $e->getMessage();
        }
        

      }

      public function curlApi(){
        $curl = curl_init();
        $url='https://swapi.dev/api/people/';
        $headers = array(
            "Content-Type: application/json"
        );
        curl_setopt_array($curl, 
        array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",	
            CURLOPT_HTTPHEADER => $headers,
        ));
        
        $response = curl_exec($curl);

        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "e:e";
        } else {
            $response = json_decode($response);
            return $response;
        }
      }
}
