<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Session;
use App\People;

class PeopleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $itemsPerPage = 25;
        $people = People::orderBy('created_at', 'desc')->paginate($itemsPerPage);
        return view('people.index', array('people' => $people, 'title' => 'People List'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('people.create', array('title' => 'Add People'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, array(
            'name' => 'required',
            'height' => 'required|numeric',
            'films' => 'required',
            'hair_color' => 'required',
            'skin_color' => 'required',
        ));
        $input = $request->all();
        //dd($input); 
        People::create($input);
        Session::flash('flash_message', 'Peoples added successfully!');
        return redirect()->route('people.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $people = People::where('id', $id)->first();
        return view('people.show', array('people' => $people));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $people = People::findOrFail($id);
		return view('people.edit', array('people' => $people, 'title' => 'Edit People'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $people = People::findOrFail($id);
		$this->validate($request, array(
            'name' => 'required',
            'height' => 'required|numeric',
            'films' => 'required',
            'hair_color' => 'required',
            'skin_color' => 'required',
			));
		$input = $request->all();
		$people->fill($input)->save();
		Session::flash('flash_message', 'People updated successfully!');
		return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $people = People::findOrFail($id);
		$people->delete();
		Session::flash('flash_message', 'People deleted successfully!');
		return redirect()->route('people.index');
    }

}
