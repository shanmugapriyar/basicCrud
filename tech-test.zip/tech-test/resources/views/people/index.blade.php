@extends('layouts.master')

@section('title', $title)

@section('sidebar')
    @parent
    
@endsection


@section('content')	
	<h1>Peoples</h1>
	
		<div style="width:60%; border-bottom:1px solid #aaa">
			<p>
				
				<br>
                <table class="table table-striped dataTable no-footer" style="border: 1px solid black;">
                <thead>
                <tr>
                <th style="border: 1px solid black;">Name</th>
                <th style="border: 1px solid black;">Height</th>
                <th style="border: 1px solid black;">Skin Color</th>
                <th style="border: 1px solid black;">Action</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($people as $data)
                <tr>
                <td style="border: 1px solid black;"><a href="{{ route('people.show', $data->id) }}">{{ $data->name }}</a></td>
                <td style="border: 1px solid black;">{{ $data->height }}</td>
                <td style="border: 1px solid black;">{{ $data->skin_color }}</td>
                <td style="border: 1px solid black;"><div>
					<span style="float:left"> 
						<a href="{{ route('people.edit', $data->id) }}">Edit</a>  
					</span>	
					
					<!-- Delete should be a button -->
					{!! Form::open(array(
							'method' => 'DELETE',
							'route' => ['people.destroy', $data->id],
							'onsubmit' => "return confirm('Are you sure you want to delete?')",
						)) 
					!!}
						{!! Form::submit('Delete') !!}
					{!! Form::close() !!}
					<!-- End Delete button -->
				</div></td>
                </tr>
                @endforeach
                </tbody>


                </table>			
				 
				
			</p>
					</div>
	
	
	<!-- Showing Pagination Links -->
	<style>
		ul {display:inline-block}
		li {display:inline; padding:5px}
	</style>	
	<div> </div>
	<!-- End Showing Pagination Links -->
		
@endsection