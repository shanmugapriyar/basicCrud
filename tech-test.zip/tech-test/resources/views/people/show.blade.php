@extends('layouts.master')

@section('title', $people->name)

@section('sidebar')
    @parent
    // you can add something here
@endsection

@section('content')	
	<h1>{{ $people->name }}</h1>
	
	Height: {{ $people->height }} | Skin Color: {{ $people->skin_color }} | Hair Color: {{ $people->hair_color }}
	
	<p>{{ $people->films }}</p>
	
@endsection
