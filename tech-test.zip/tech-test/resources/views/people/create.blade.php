@extends('layouts.master')

@section('title', $title)

@section('sidebar')
    @parent
    // you can add something here
@endsection

@section('content')

	<h1>{{ $title }}</h1>

	{!! Form::open([
		'route' => 'people.store'
	]) !!}

	<table>
		<tr>
			<td>{!! Form::label('name', 'Title', ['class' => 'control-label']) !!}</td>
			<td>{!! Form::text('name', null, ['class' => 'form-control', 'size' => 64, ]) !!}</td>
		</tr>
		<tr>
			<td>{!! Form::label('height', 'Height', ['class' => 'control-label']) !!}</td>
			<td>{!! Form::text('height', null, ['class' => 'form-control', 'size' => 64, ]) !!}</td>
		</tr>
		<tr>
			<td>{!! Form::label('hair_color', 'Hair Color', ['class' => 'control-label']) !!}</td>
			<td>{!! Form::text('hair_color', null, ['class' => 'form-control', 'size' => 64, ]) !!}</td>
		</tr>
		<tr>
			<td>{!! Form::label('skin_color', 'Skin Color', ['class' => 'control-label']) !!}</td>
			<td>{!! Form::text('skin_color', null, ['class' => 'form-control', 'size' => 64, ]) !!}</td>
		</tr>
		<tr>
			<td valign="top">{!! Form::label('films', 'Films', ['class' => 'control-label']) !!}</td>
			<td>{!! Form::textarea('films', null, ['class' => 'form-control']) !!}</td>
		</tr>	
		<tr>
			<td></td>
			<td>{!! Form::submit('Submit', ['class' => 'btn btn-submit']) !!}</td>
		</tr>
	</table>		
	
	{!! Form::close() !!}

@endsection